/*
 * Copyright 2015 blondiebytes
 */
package helloworld;

/**
 *
 * @author kathrynhodge
 */
public class HelloWorld {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Hello World!");
    }
    
}
