
package starwarsinterfacepractice;

public interface Character {
    public String base = "character";
    public void attack();
    public void heal();
    public String getWeapon();
}
