/*
 * Copyright 2015 blondiebytes
 */

package person;

/**
 * @author kathrynhodge
 */

public class NewClass {

}
