/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package person;

/**
 *
 * @author kathrynhodge
 */
public enum HairColor {
    BLONDE, BROWN, BLACK, RED, ORANGE, PINK, BLUE, GREEN, PURPLE, RAINBOW, OTHER
}
