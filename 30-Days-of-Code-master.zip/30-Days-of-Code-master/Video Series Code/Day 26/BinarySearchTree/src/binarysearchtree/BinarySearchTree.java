/*
 * Copyright 2015 blondiebytes
 */
package binarysearchtree;

/**
 *
 * @author kathrynhodge
 */
public class BinarySearchTree {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        // TODO code application logic here
        EmptyBST e = new EmptyBST();
        NonEmptyBST n = new NonEmptyBST(5);
        Testers.checkIsEmpty(e);
        Testers.checkIsEmpty(n);
         Testers.checkIsEmpty(e);
        Testers.checkIsEmpty(n);
         Testers.checkIsEmpty(e);
        Testers.checkIsEmpty(n);
         Testers.checkIsEmpty(e);
        Testers.checkIsEmpty(n);
         Testers.checkIsEmpty(e);
        Testers.checkIsEmpty(n); Testers.checkIsEmpty(e);
        Testers.checkIsEmpty(n); Testers.checkIsEmpty(e);
        Testers.checkIsEmpty(n);
         Testers.checkIsEmpty(e);
        Testers.checkIsEmpty(n);
         Testers.checkIsEmpty(e);
        Testers.checkIsEmpty(n);
         Testers.checkIsEmpty(e);
        Testers.checkIsEmpty(n);
         Testers.checkIsEmpty(e);
        Testers.checkIsEmpty(n);
         Testers.checkIsEmpty(e);
        Testers.checkIsEmpty(n); Testers.checkIsEmpty(e);
        Testers.checkIsEmpty(n);
         Testers.checkIsEmpty(e);
        Testers.checkIsEmpty(n);
         Testers.checkIsEmpty(e);
        Testers.checkIsEmpty(n);
         Testers.checkIsEmpty(e);
        Testers.checkIsEmpty(n);
         Testers.checkIsEmpty(e);
        Testers.checkIsEmpty(n); Testers.checkIsEmpty(e);
        Testers.checkIsEmpty(n);
        
        
        
        
    }
    
}
