# 30 Days of Code
A 30-day video tutorial series for people with no programming experience that want to learn how to code.

<a href="https://www.codementor.io/blondiebytes?utm_source=github&utm_medium=button&utm_term=blondiebytes&utm_campaign=github"><img src="https://cdn.codementor.io/badges/book_session_github.svg" alt="Book session on Codementor" style="max-width:100%" /></a>
