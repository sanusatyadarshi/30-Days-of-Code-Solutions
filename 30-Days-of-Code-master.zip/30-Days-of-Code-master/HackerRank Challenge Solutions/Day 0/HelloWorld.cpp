#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;


int main() {
    cout<<"Hello World."<<endl;
    cout<<"Welcome to 30 Days of Code.";
    return 0;
}