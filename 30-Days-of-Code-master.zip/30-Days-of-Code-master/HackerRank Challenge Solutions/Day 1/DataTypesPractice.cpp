#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;


int main() {
    /* Enter your code here. Read input from STDIN. Print output to STDOUT */  
    
    cout<<"Primitive : double"<<endl;
    cout<<"Primitive : char"<<endl;
    cout<<"Primitive : boolean"<<endl;
    cout<<"Primitive : int"<<endl;
    cout<<"Referenced : String"<<endl;
    cout<<"Primitive : boolean"<<endl;
    cout<<"Primitive : double"<<endl;
    cout<<"Primitive : char"<<endl;
    cout<<"Referenced : String"<<endl;
    
    
    
    return 0;
}